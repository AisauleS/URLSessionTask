import UIKit

func makeUrlSessionWithTimeout(_ timeout: TimeInterval) -> URLSession {
       let configuration = URLSessionConfiguration.default
       configuration.allowsCellularAccess = false
       configuration.waitsForConnectivity = true
       configuration.timeoutIntervalForRequest = timeout
       return URLSession(configuration: configuration)
   }

func getData(urlRequest: String) {
    let urlRequest = URL(string: urlRequest)
    guard let url = urlRequest else {return}

    let urlSession = makeUrlSessionWithTimeout(10)
    urlSession.dataTask(with: url) { data, response, error in
        if error != nil {
            print(error ?? "Error detected")
        } else if let response = response as? HTTPURLResponse, response.statusCode == 200 {
            guard let data = data else { return }
            let dataAsString = String(data: data, encoding: .utf8)
            print("Status code: \(response.statusCode)")
            print("JSON data: \(String(describing: dataAsString))")
        }
    }.resume()
}

getData(urlRequest: "https://api.artic.edu/api/v1/artworks")
